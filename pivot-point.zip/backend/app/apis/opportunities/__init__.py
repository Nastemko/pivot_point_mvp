from fastapi import APIRouter, HTTPException
from pydantic import BaseModel, Field
import databutton as db
from app.auth import AuthorizedUser
from google.oauth2 import service_account
from google.cloud import firestore
import json

router = APIRouter()

# --- Explicitly initialize Firestore client with service account ---
# Get credentials from Databutton secrets
creds_json_str = db.secrets.get("FIREBASE_ADMIN_SDK_CREDENTIALS")
creds_info = json.loads(creds_json_str)
credentials = service_account.Credentials.from_service_account_info(creds_info)

# Initialize client with the explicit credentials
db_client = firestore.Client(credentials=credentials)
# --- End of explicit initialization ---

class Opportunity(BaseModel):
    title: str
    description: str
    reach: int
    impact: int = Field(..., ge=1, le=5)
    confidence: int = Field(..., ge=0, le=100)
    effort: int
    user_id: str

class OpportunityUpdate(BaseModel):
    title: str
    description: str
    reach: int
    impact: int = Field(..., ge=1, le=5)
    confidence: int = Field(..., ge=0, le=100)
    effort: int

class OpportunityResponse(Opportunity):
    id: str
    rice_score: float

@router.post("/opportunities", response_model=OpportunityResponse)
async def create_opportunity(opportunity: Opportunity, user: AuthorizedUser):
    """
    Create a new opportunity and save it to Firestore.
    Calculates the R.I.C.E. score.
    """
    if user.sub != opportunity.user_id:
        raise HTTPException(status_code=403, detail="User ID does not match authenticated user")

    rice_score = (opportunity.reach * opportunity.impact * (opportunity.confidence / 100)) / opportunity.effort

    # Create a new document in the 'opportunities' collection
    doc_ref = db_client.collection("opportunities").document()
    opportunity_data = opportunity.dict()
    opportunity_data["rice_score"] = rice_score

    doc_ref.set(opportunity_data)

    return OpportunityResponse(id=doc_ref.id, **opportunity_data)


@router.get("/opportunities", response_model=list[OpportunityResponse])
async def list_opportunities(user: AuthorizedUser):
    """
    List all opportunities for the authenticated user.
    """
    opportunities = []
    docs = db_client.collection("opportunities").where("user_id", "==", user.sub).stream()
    for doc in docs:
        opportunity_data = doc.to_dict()
        opportunities.append(OpportunityResponse(id=doc.id, **opportunity_data))
    return opportunities

@router.put("/opportunities/{opportunity_id}", response_model=OpportunityResponse)
async def update_opportunity(opportunity_id: str, opportunity_update: OpportunityUpdate, user: AuthorizedUser):
    """
    Update an existing opportunity in Firestore.
    Recalculates the R.I.C.E. score.
    """
    doc_ref = db_client.collection("opportunities").document(opportunity_id)
    
    # Verify the opportunity exists and belongs to the user
    opportunity_doc = doc_ref.get()
    if not opportunity_doc.exists:
        raise HTTPException(status_code=404, detail="Opportunity not found")
    
    opportunity_data = opportunity_doc.to_dict()
    if opportunity_data.get("user_id") != user.sub:
        raise HTTPException(status_code=403, detail="User not authorized to update this opportunity")

    # Recalculate R.I.C.E. score
    rice_score = (opportunity_update.reach * opportunity_update.impact * (opportunity_update.confidence / 100)) / opportunity_update.effort
    
    update_data = opportunity_update.dict()
    update_data["rice_score"] = rice_score
    
    # Update the document in Firestore
    doc_ref.update(update_data)
    
    # Construct and return the full response
    full_data = opportunity_data | update_data # Merge original and new data
    full_data.pop('user_id', None) # Remove user_id to avoid duplication
    return OpportunityResponse(id=opportunity_id, **full_data, user_id=user.sub)

@router.delete("/opportunities/{opportunity_id}", status_code=204)
async def delete_opportunity(opportunity_id: str, user: AuthorizedUser):
    """
    Delete an opportunity from Firestore.
    """
    doc_ref = db_client.collection("opportunities").document(opportunity_id)
    
    # Verify the opportunity exists and belongs to the user
    opportunity_doc = doc_ref.get()
    if not opportunity_doc.exists:
        # We can return 204 even if not found to make it idempotent
        return

    opportunity_data = opportunity_doc.to_dict()
    if opportunity_data.get("user_id") != user.sub:
        # If the user is not authorized, we can return a 403 or just pretend
        # it was deleted. Returning 204 is simpler and hides existence.
        return
        
    # Delete the document
    doc_ref.delete()
    
    return
