/** HTTPValidationError */
export interface HTTPValidationError {
  /** Detail */
  detail?: ValidationError[];
}

/** HealthResponse */
export interface HealthResponse {
  /** Status */
  status: string;
}

/** Opportunity */
export interface Opportunity {
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Reach */
  reach: number;
  /**
   * Impact
   * @min 1
   * @max 5
   */
  impact: number;
  /**
   * Confidence
   * @min 0
   * @max 100
   */
  confidence: number;
  /** Effort */
  effort: number;
  /** User Id */
  user_id: string;
}

/** OpportunityResponse */
export interface OpportunityResponse {
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Reach */
  reach: number;
  /**
   * Impact
   * @min 1
   * @max 5
   */
  impact: number;
  /**
   * Confidence
   * @min 0
   * @max 100
   */
  confidence: number;
  /** Effort */
  effort: number;
  /** User Id */
  user_id: string;
  /** Id */
  id: string;
  /** Rice Score */
  rice_score: number;
}

/** OpportunityUpdate */
export interface OpportunityUpdate {
  /** Title */
  title: string;
  /** Description */
  description: string;
  /** Reach */
  reach: number;
  /**
   * Impact
   * @min 1
   * @max 5
   */
  impact: number;
  /**
   * Confidence
   * @min 0
   * @max 100
   */
  confidence: number;
  /** Effort */
  effort: number;
}

/** ValidationError */
export interface ValidationError {
  /** Location */
  loc: (string | number)[];
  /** Message */
  msg: string;
  /** Error Type */
  type: string;
}

export type CheckHealthData = HealthResponse;

/** Response List Opportunities */
export type ListOpportunitiesData = OpportunityResponse[];

export type CreateOpportunityData = OpportunityResponse;

export type CreateOpportunityError = HTTPValidationError;

export interface UpdateOpportunityParams {
  /** Opportunity Id */
  opportunityId: string;
}

export type UpdateOpportunityData = OpportunityResponse;

export type UpdateOpportunityError = HTTPValidationError;

export interface DeleteOpportunityParams {
  /** Opportunity Id */
  opportunityId: string;
}

export type DeleteOpportunityData = any;

export type DeleteOpportunityError = HTTPValidationError;
