import {
  CheckHealthData,
  CreateOpportunityData,
  DeleteOpportunityData,
  ListOpportunitiesData,
  Opportunity,
  OpportunityUpdate,
  UpdateOpportunityData,
} from "./data-contracts";

export namespace Brain {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  export namespace check_health {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = CheckHealthData;
  }

  /**
   * @description List all opportunities for the authenticated user.
   * @tags dbtn/module:opportunities, dbtn/hasAuth
   * @name list_opportunities
   * @summary List Opportunities
   * @request GET:/routes/opportunities
   */
  export namespace list_opportunities {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = ListOpportunitiesData;
  }

  /**
   * @description Create a new opportunity and save it to Firestore. Calculates the R.I.C.E. score.
   * @tags dbtn/module:opportunities, dbtn/hasAuth
   * @name create_opportunity
   * @summary Create Opportunity
   * @request POST:/routes/opportunities
   */
  export namespace create_opportunity {
    export type RequestParams = {};
    export type RequestQuery = {};
    export type RequestBody = Opportunity;
    export type RequestHeaders = {};
    export type ResponseBody = CreateOpportunityData;
  }

  /**
   * @description Update an existing opportunity in Firestore. Recalculates the R.I.C.E. score.
   * @tags dbtn/module:opportunities, dbtn/hasAuth
   * @name update_opportunity
   * @summary Update Opportunity
   * @request PUT:/routes/opportunities/{opportunity_id}
   */
  export namespace update_opportunity {
    export type RequestParams = {
      /** Opportunity Id */
      opportunityId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = OpportunityUpdate;
    export type RequestHeaders = {};
    export type ResponseBody = UpdateOpportunityData;
  }

  /**
   * @description Delete an opportunity from Firestore.
   * @tags dbtn/module:opportunities, dbtn/hasAuth
   * @name delete_opportunity
   * @summary Delete Opportunity
   * @request DELETE:/routes/opportunities/{opportunity_id}
   */
  export namespace delete_opportunity {
    export type RequestParams = {
      /** Opportunity Id */
      opportunityId: string;
    };
    export type RequestQuery = {};
    export type RequestBody = never;
    export type RequestHeaders = {};
    export type ResponseBody = DeleteOpportunityData;
  }
}
