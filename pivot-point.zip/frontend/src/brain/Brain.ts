import {
  CheckHealthData,
  CreateOpportunityData,
  CreateOpportunityError,
  DeleteOpportunityData,
  DeleteOpportunityError,
  DeleteOpportunityParams,
  ListOpportunitiesData,
  Opportunity,
  OpportunityUpdate,
  UpdateOpportunityData,
  UpdateOpportunityError,
  UpdateOpportunityParams,
} from "./data-contracts";
import { ContentType, HttpClient, RequestParams } from "./http-client";

export class Brain<SecurityDataType = unknown> extends HttpClient<SecurityDataType> {
  /**
   * @description Check health of application. Returns 200 when OK, 500 when not.
   *
   * @name check_health
   * @summary Check Health
   * @request GET:/_healthz
   */
  check_health = (params: RequestParams = {}) =>
    this.request<CheckHealthData, any>({
      path: `/_healthz`,
      method: "GET",
      ...params,
    });

  /**
   * @description List all opportunities for the authenticated user.
   *
   * @tags dbtn/module:opportunities, dbtn/hasAuth
   * @name list_opportunities
   * @summary List Opportunities
   * @request GET:/routes/opportunities
   */
  list_opportunities = (params: RequestParams = {}) =>
    this.request<ListOpportunitiesData, any>({
      path: `/routes/opportunities`,
      method: "GET",
      ...params,
    });

  /**
   * @description Create a new opportunity and save it to Firestore. Calculates the R.I.C.E. score.
   *
   * @tags dbtn/module:opportunities, dbtn/hasAuth
   * @name create_opportunity
   * @summary Create Opportunity
   * @request POST:/routes/opportunities
   */
  create_opportunity = (data: Opportunity, params: RequestParams = {}) =>
    this.request<CreateOpportunityData, CreateOpportunityError>({
      path: `/routes/opportunities`,
      method: "POST",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Update an existing opportunity in Firestore. Recalculates the R.I.C.E. score.
   *
   * @tags dbtn/module:opportunities, dbtn/hasAuth
   * @name update_opportunity
   * @summary Update Opportunity
   * @request PUT:/routes/opportunities/{opportunity_id}
   */
  update_opportunity = (
    { opportunityId, ...query }: UpdateOpportunityParams,
    data: OpportunityUpdate,
    params: RequestParams = {},
  ) =>
    this.request<UpdateOpportunityData, UpdateOpportunityError>({
      path: `/routes/opportunities/${opportunityId}`,
      method: "PUT",
      body: data,
      type: ContentType.Json,
      ...params,
    });

  /**
   * @description Delete an opportunity from Firestore.
   *
   * @tags dbtn/module:opportunities, dbtn/hasAuth
   * @name delete_opportunity
   * @summary Delete Opportunity
   * @request DELETE:/routes/opportunities/{opportunity_id}
   */
  delete_opportunity = ({ opportunityId, ...query }: DeleteOpportunityParams, params: RequestParams = {}) =>
    this.request<DeleteOpportunityData, DeleteOpportunityError>({
      path: `/routes/opportunities/${opportunityId}`,
      method: "DELETE",
      ...params,
    });
}
