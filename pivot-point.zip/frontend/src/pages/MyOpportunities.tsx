import React, { useEffect, useState } from "react";
import brain from "brain";
import { OpportunityResponse } from "brain/data-contracts";
import { useCurrentUser } from "app";
import { useNavigate } from "react-router-dom";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog";

export default function MyOpportunities() {
  const { user } = useCurrentUser();
  const [opportunities, setOpportunities] = useState<OpportunityResponse[]>([]);
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      const fetchOpportunities = async () => {
        try {
          const response = await brain.list_opportunities();
          const data = await response.json();
          setOpportunities(data);
        } catch (error) {
          console.error("Failed to fetch opportunities:", error);
        }
      };

      fetchOpportunities();
    }
  }, [user]);

  const handleDelete = async (opportunityId: string) => {
    try {
      await brain.delete_opportunity({ opportunityId });
      setOpportunities((prev) =>
        prev.filter((opp) => opp.id !== opportunityId),
      );
    } catch (error) {
      console.error("Failed to delete opportunity:", error);
    }
  };

  return (
    <div className="flex-1 p-4 md:p-6">
      <div className="flex items-center mb-4">
        <h1 className="font-semibold text-lg md:text-2xl">My Opportunities</h1>
        <Button className="ml-auto" onClick={() => navigate("/create-opportunity")}>
          Create New
        </Button>
      </div>
      <Card>
        <CardContent className="pt-6">
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Title</TableHead>
                <TableHead>Description</TableHead>
                <TableHead>R.I.C.E. Score</TableHead>
                <TableHead>Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {opportunities.map((opp) => (
                <TableRow key={opp.id}>
                  <TableCell>{opp.title}</TableCell>
                  <TableCell>{opp.description}</TableCell>
                  <TableCell>{opp.rice_score.toFixed(2)}</TableCell>
                  <TableCell className="space-x-2">
                    <Button
                      variant="outline"
                      size="sm"
                      onClick={() =>
                        navigate(`/edit-opportunity?id=${opp.id}`)
                      }
                    >
                      Edit
                    </Button>
                    <AlertDialog>
                      <AlertDialogTrigger asChild>
                        <Button variant="destructive" size="sm">
                          Delete
                        </Button>
                      </AlertDialogTrigger>
                      <AlertDialogContent>
                        <AlertDialogHeader>
                          <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                          <AlertDialogDescription>
                            This action cannot be undone. This will permanently
                            delete the opportunity "{opp.title}".
                          </AlertDialogDescription>
                        </AlertDialogHeader>
                        <AlertDialogFooter>
                          <AlertDialogCancel>Cancel</AlertDialogCancel>
                          <AlertDialogAction
                            onClick={() => handleDelete(opp.id)}
                          >
                            Continue
                          </AlertDialogAction>
                        </AlertDialogFooter>
                      </AlertDialogContent>
                    </AlertDialog>
                  </TableCell>
                </TableRow>
              ))}
            </TableBody>
          </Table>
        </CardContent>
      </Card>
    </div>
  );
}
