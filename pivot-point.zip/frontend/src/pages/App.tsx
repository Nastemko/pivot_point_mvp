import React from "react";
import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Check, BarChart, FlaskConical, Target } from "lucide-react";
import { useCurrentUser } from "app";
import { useNavigate } from "react-router-dom";

export default function App() {
  const { user } = useCurrentUser();
  const navigate = useNavigate();

  return (
    <div className="flex-1">
      {user ? (
        <div className="p-4 md:p-6">
          <div className="flex items-center mb-6">
            <h1 className="font-semibold text-2xl md:text-3xl">
              Welcome, {user.displayName || "User"}!
            </h1>
          </div>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
            <Card className="flex flex-col">
              <CardHeader>
                <CardTitle>My Opportunities</CardTitle>
                <CardDescription>
                  View, manage, and track your existing product opportunities.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow flex items-end">
                <Button
                  className="w-full"
                  onClick={() => navigate("/my-opportunities")}
                >
                  View Opportunities
                </Button>
              </CardContent>
            </Card>
            <Card className="flex flex-col">
              <CardHeader>
                <CardTitle>Create New Opportunity</CardTitle>
                <CardDescription>
                  Define and score a new opportunity using the R.I.C.E.
                  framework.
                </CardDescription>
              </CardHeader>
              <CardContent className="flex-grow flex items-end">
                <Button
                  className="w-full"
                  variant="outline"
                  onClick={() => navigate("/create-opportunity")}
                >
                  Create Opportunity
                </Button>
              </CardContent>
            </Card>
          </div>
        </div>
      ) : (
        <div className="p-4 md:p-6 text-center">
          <h1 className="font-semibold text-lg md:text-2xl">
            Welcome to OptiScore
          </h1>
          <p className="text-muted-foreground mt-2">
            Please log in to see your opportunities.
          </p>
        </div>
      )}
    </div>
  );
}

// Rerunning after explicit Firestore client initialization
