import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardDescription,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Slider } from "@/components/ui/slider";
import brain from "brain";
import { useCurrentUser } from "app";
import { useNavigate } from "react-router-dom";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import * as z from "zod";
import {
  Form,
  FormControl,
  FormDescription,
  FormField,
  FormItem,
  FormLabel,
  FormMessage,
} from "@/components/ui/form";
import { InfoTooltip } from "components/InfoTooltip";

const formSchema = z.object({
  title: z.string().min(1),
  description: z.string().min(1),
  reach: z.number().min(1),
  impact: z.number().min(1).max(5),
  confidence: z.number().min(0).max(100),
  effort: z.number().min(1),
});

export default function CreateOpportunity() {
  const { user } = useCurrentUser();
  const navigate = useNavigate();
  const form = useForm<z.infer<typeof formSchema>>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      title: "",
      description: "",
      reach: 1,
      impact: 1,
      confidence: 1,
      effort: 1,
    },
  });

  const tooltipContent = {
    reach:
      "How many people will this initiative affect within a specific time period? (e.g., customers per quarter, users per month). This helps to quantify the potential audience size.",
    impact:
      "How much will this initiative increase a key metric? (e.g., conversion rate, user satisfaction). This is often scored on a scale from 0.25 (minimal) to 3 (massive).",
    confidence:
      "How confident are you in your estimates for Reach, Impact, and Effort? This is expressed as a percentage, from 50% (low confidence) to 100% (high confidence).",
    effort:
      'What is the total amount of work required from your team (product, design, engineering)? This is typically estimated in "person-months" or "sprint-weeks."',
  };

  async function onSubmit(values: z.infer<typeof formSchema>) {
    if (!user) {
      // This should ideally not happen if the form is disabled, but as a safeguard
      alert("You must be logged in to create an opportunity.");
      return;
    }
    try {
      await brain.create_opportunity({ ...values, user_id: user.uid });
      alert("Opportunity created successfully!");
      navigate("/");
    } catch (error) {
      console.error("Failed to create opportunity:", error);
      alert("Failed to create opportunity. Please try again.");
    }
  }

  return (
    <div className="flex justify-center items-center min-h-screen bg-background">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Create New Opportunity</CardTitle>
          <CardDescription>Fill out the form to create a new opportunity.</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)}>
              <div className="grid gap-4">
                <div className="grid gap-2">
                  <FormField
                    control={form.control}
                    name="title"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Title</FormLabel>
                        <FormControl>
                          <Input
                            id="title"
                            placeholder="e.g., New feature for our app"
                            {...field}
                            required
                          />
                        </FormControl>
                        <FormDescription>
                          The title of the opportunity.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid gap-2">
                  <FormField
                    control={form.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Description</FormLabel>
                        <FormControl>
                          <Textarea
                            id="description"
                            placeholder="Describe the opportunity..."
                            {...field}
                          />
                        </FormControl>
                        <FormDescription>
                          The description of the opportunity.
                        </FormDescription>
                        <FormMessage />
                      </FormItem>
                    )}
                  />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <FormField
                      control={form.control}
                      name="reach"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex items-center space-x-2">
                            <FormLabel>Reach</FormLabel>
                            <InfoTooltip content={tooltipContent.reach} />
                          </div>
                          <FormControl>
                            <Input
                              id="reach"
                              type="number"
                              placeholder="Number of users per month"
                              {...field}
                              required
                            />
                          </FormControl>
                          <FormDescription>
                            The number of users affected by the opportunity.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="grid gap-2">
                    <FormField
                      control={form.control}
                      name="impact"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex items-center space-x-2">
                            <FormLabel>Impact (1-5)</FormLabel>
                            <InfoTooltip content={tooltipContent.impact} />
                          </div>
                          <FormControl>
                            <Input
                              id="impact"
                              type="number"
                              min="1"
                              max="5"
                              placeholder="1 (low) to 5 (high)"
                              {...field}
                              required
                            />
                          </FormControl>
                          <FormDescription>
                            The impact of the opportunity on the business.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="grid gap-2">
                    <FormField
                      control={form.control}
                      name="confidence"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex items-center space-x-2">
                            <FormLabel>Confidence (%)</FormLabel>
                            <InfoTooltip content={tooltipContent.confidence} />
                          </div>
                          <FormControl>
                            <Input
                              id="confidence"
                              type="number"
                              min="0"
                              max="100"
                              placeholder="e.g., 80"
                              {...field}
                              required
                            />
                          </FormControl>
                          <FormDescription>
                            The confidence level of the opportunity.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                  <div className="grid gap-2">
                    <FormField
                      control={form.control}
                      name="effort"
                      render={({ field }) => (
                        <FormItem>
                          <div className="flex items-center space-x-2">
                            <FormLabel>Effort (Story Points)</FormLabel>
                            <InfoTooltip content={tooltipContent.effort} />
                          </div>
                          <FormControl>
                            <Input
                              id="effort"
                              type="number"
                              placeholder="e.g., 5"
                              {...field}
                              required
                            />
                          </FormControl>
                          <FormDescription>
                            The effort required to implement the opportunity.
                          </FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>
                </div>
                <Button type="submit" disabled={!user || form.formState.isSubmitting}>
                  Create Opportunity
                </Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  );
}
