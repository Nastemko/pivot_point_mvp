import { useEffect, useState } from "react";
import brain from "brain";
import {
  ScatterChart,
  Scatter,
  XAxis,
  YAxis,
  ZAxis,
  CartesianGrid,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Opportunity } from "types";

const CustomTooltip = ({ active, payload }: any) => {
  if (active && payload && payload.length) {
    const data = payload[0].payload;
    const riceScore =
      (data.reach * data.impact * data.confidence) / data.effort;
    return (
      <div className="p-2 border bg-background rounded-lg shadow-lg">
        <p className="font-bold">{data.title}</p>
        <p>
          <b>R.I.C.E. Score:</b> {riceScore.toFixed(2)}
        </p>
        <p>
          <b>Reach:</b> {data.reach}
        </p>
        <p>
          <b>Impact:</b> {data.impact}
        </p>
        <p>
          <b>Confidence:</b> {data.confidence}%
        </p>
        <p>
          <b>Effort:</b> {data.effort}
        </p>
      </div>
    );
  }

  return null;
};

export default function PrioritizationMatrix() {
  const [opportunities, setOpportunities] = useState<Opportunity[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchOpportunities = async () => {
      try {
        const response = await brain.list_opportunities();
        const data = await response.json();
        if (Array.isArray(data)) {
          setOpportunities(data);
        }
      } catch (error) {
        console.error("Failed to fetch opportunities:", error);
      } finally {
        setLoading(false);
      }
    };

    fetchOpportunities();
  }, []);

  if (loading) {
    return <div>Loading...</div>;
  }

  return (
    <div className="container mx-auto p-4">
      <Card>
        <CardHeader>
          <CardTitle>Prioritization Matrix</CardTitle>
        </CardHeader>
        <CardContent className="h-96">
          <ResponsiveContainer width="100%" height="100%">
            <ScatterChart
              margin={{
                top: 20,
                right: 20,
                bottom: 20,
                left: 20,
              }}
            >
              <CartesianGrid />
              <XAxis type="number" dataKey="effort" name="Effort" />
              <YAxis type="number" dataKey="impact" name="Impact" />
              <ZAxis type="number" dataKey="reach" name="Reach" range={[60, 400]} />
              <Tooltip cursor={{ strokeDasharray: "3 3" }} content={<CustomTooltip />} />
              <Legend />
              <Scatter
                name="Opportunities"
                data={opportunities}
                fill="#8884d8"
              />
            </ScatterChart>
          </ResponsiveContainer>
        </CardContent>
      </Card>
    </div>
  );
}
