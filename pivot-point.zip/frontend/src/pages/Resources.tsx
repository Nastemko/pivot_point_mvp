import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";

export default function Resources() {
  return (
    <div className="container mx-auto p-4 md:p-6">
      <h1 className="text-3xl font-bold mb-6">Framework Resources</h1>

      <div className="space-y-8">
        <div>
          <h2 className="text-2xl font-semibold mb-4">The R.I.C.E. Framework</h2>
          <p className="text-muted-foreground mb-6">
            R.I.C.E. is a simple and effective scoring framework for prioritizing
            product ideas and initiatives. It helps you make data-driven decisions
            by evaluating four key factors. The final score is calculated as:
            <br />
            <b className="font-mono text-lg">(Reach * Impact * Confidence) / Effort</b>
          </p>
          <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            <Card>
              <CardHeader>
                <CardTitle>Reach</CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  How many people will this initiative affect within a specific
                  time period? (e.g., customers per quarter, users per month).
                  This helps to quantify the potential audience size.
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Impact</CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  How much will this initiative increase a key metric? (e.g.,
                  conversion rate, user satisfaction). This is often scored on a
                  scale from 0.25 (minimal) to 3 (massive).
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Confidence</CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  How confident are you in your estimates for Reach, Impact, and
                  Effort? This is expressed as a percentage, from 50% (low
                  confidence) to 100% (high confidence).
                </p>
              </CardContent>
            </Card>
            <Card>
              <CardHeader>
                <CardTitle>Effort</CardTitle>
              </CardHeader>
              <CardContent>
                <p>
                  What is the total amount of work required from your team
                  (product, design, engineering)? This is typically estimated in
                  "person-months" or "sprint-weeks."
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
}
