import { Button } from "@/components/ui/button";
import {
  Card,
  CardContent,
  CardHeader,
  CardTitle,
} from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import brain from "brain";
import { useCurrentUser } from "app";
import { useEffect, useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { OpportunityResponse } from "brain/data-contracts";
import { InfoTooltip } from "components/InfoTooltip";

export default function EditOpportunity() {
  const [searchParams] = useSearchParams();
  const opportunityId = searchParams.get("id");
  const navigate = useNavigate();
  const { user } = useCurrentUser();

  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [reach, setReach] = useState(0);
  const [impact, setImpact] = useState(1);
  const [confidence, setConfidence] = useState(80);
  const [effort, setEffort] = useState(1);
  const [error, setError] = useState<string | null>(null);
  const [loading, setLoading] = useState(false);
  const [fetching, setFetching] = useState(true);

  const tooltipContent = {
    reach:
      "How many people will this initiative affect within a specific time period? (e.g., customers per quarter, users per month). This helps to quantify the potential audience size.",
    impact:
      "How much will this initiative increase a key metric? (e.g., conversion rate, user satisfaction). This is often scored on a scale from 0.25 (minimal) to 3 (massive).",
    confidence:
      "How confident are you in your estimates for Reach, Impact, and Effort? This is expressed as a percentage, from 50% (low confidence) to 100% (high confidence).",
    effort:
      'What is the total amount of work required from your team (product, design, engineering)? This is typically estimated in "person-months" or "sprint-weeks."',
  };

  useEffect(() => {
    const fetchOpportunity = async () => {
      if (!opportunityId || !user) {
        setFetching(false);
        return;
      }
      try {
        setFetching(true);
        // We can fetch all and find the one, or create a new endpoint.
        // For simplicity, let's assume we can get it from the list.
        // In a real app, a getOpportunityById endpoint would be better.
        const response = await brain.list_opportunities();
        const opportunities = await response.json();
        const currentOpp = opportunities.find(
          (o: OpportunityResponse) => o.id === opportunityId
        );

        if (currentOpp) {
          setTitle(currentOpp.title);
          setDescription(currentOpp.description);
          setReach(currentOpp.reach);
          setImpact(currentOpp.impact);
          setConfidence(currentOpp.confidence);
          setEffort(currentOpp.effort);
        } else {
          setError("Opportunity not found.");
        }
      } catch (err) {
        setError("Failed to fetch opportunity data.");
        console.error(err);
      } finally {
        setFetching(false);
      }
    };

    fetchOpportunity();
  }, [opportunityId, user]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!user || !opportunityId) return;

    setLoading(true);
    setError(null);

    try {
      await brain.update_opportunity(
        { opportunityId: opportunityId },
        {
          title,
          description,
          reach,
          impact,
          confidence,
          effort,
        }
      );
      navigate("/");
    } catch (err: any) {
      setError(err.response?.data?.detail || "An unexpected error occurred.");
      console.error(err);
    } finally {
      setLoading(false);
    }
  };

  if (fetching) {
    return (
      <div className="flex justify-center items-center py-12">
        <p>Loading opportunity...</p>
      </div>
    );
  }

  return (
    <div className="flex justify-center items-center py-12">
      <Card className="w-full max-w-2xl">
        <CardHeader>
          <CardTitle>Edit Opportunity</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div>
              <Label htmlFor="title">Title</Label>
              <Input
                id="title"
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                required
              />
            </div>
            <div>
              <Label htmlFor="description">Description</Label>
              <Textarea
                id="description"
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                required
              />
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="flex items-center space-x-2">
                  <Label htmlFor="reach">Reach</Label>
                  <InfoTooltip content={tooltipContent.reach} />
                </div>
                <Input
                  id="reach"
                  type="number"
                  value={reach}
                  onChange={(e) =>
                    setReach(parseInt(e.target.value, 10) || 0)
                  }
                  required
                />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <Label htmlFor="impact">Impact (1-5)</Label>
                  <InfoTooltip content={tooltipContent.impact} />
                </div>
                <Input
                  id="impact"
                  type="number"
                  min="1"
                  max="5"
                  value={impact}
                  onChange={(e) =>
                    setImpact(parseInt(e.target.value, 10) || 0)
                  }
                  required
                />
              </div>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <div className="flex items-center space-x-2">
                  <Label htmlFor="confidence">Confidence (%)</Label>
                  <InfoTooltip content={tooltipContent.confidence} />
                </div>
                <Input
                  id="confidence"
                  type="number"
                  min="0"
                  max="100"
                  value={confidence}
                  onChange={(e) =>
                    setConfidence(parseInt(e.target.value, 10) || 0)
                  }
                  required
                />
              </div>
              <div>
                <div className="flex items-center space-x-2">
                  <Label htmlFor="effort">Effort (person-months)</Label>
                  <InfoTooltip content={tooltipContent.effort} />
                </div>
                <Input
                  id="effort"
                  type="number"
                  value={effort}
                  onChange={(e) =>
                    setEffort(parseInt(e.target.value, 10) || 0)
                  }
                  required
                />
              </div>
            </div>
            {error && (
              <p className="text-sm text-red-500 text-center mt-4">{error}</p>
            )}
            <div className="flex justify-end gap-2 mt-6">
              <Button
                type="button"
                variant="outline"
                onClick={() => navigate("/")}
              >
                Cancel
              </Button>
              <Button type="submit" disabled={loading || fetching}>
                {loading ? "Saving..." : "Save Changes"}
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  );
}
