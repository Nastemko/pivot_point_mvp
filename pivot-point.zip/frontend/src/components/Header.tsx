import { Diamond } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet";
import { useCurrentUser } from "app";
import { Link } from "react-router-dom";

export function Header() {
  const { user } = useCurrentUser();

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center justify-between">
        <div className="flex items-center space-x-4">
          <div className="mr-4 hidden md:flex">
            <Link to="/" className="mr-6 flex items-center space-x-2">
              <Diamond className="h-6 w-6" />
              <span className="hidden font-bold sm:inline-block">
                Pivot Point
              </span>
            </Link>
            <nav className="flex items-center space-x-6 text-sm font-medium">
              <Link
                to="/"
                className="transition-colors hover:text-foreground/80 text-foreground"
              >
                Home
              </Link>
              <Link
                to="/my-opportunities"
                className="transition-colors hover:text-foreground/80 text-foreground/60"
              >
                My Opportunities
              </Link>
              <Link
                to="/prioritization-matrix"
                className="transition-colors hover:text-foreground/80 text-foreground/60"
              >
                Matrix
              </Link>
            </nav>
          </div>
          <Sheet>
            <SheetTrigger asChild>
              <Button
                variant="ghost"
                size="icon"
                className="md:hidden"
              >
                <svg
                  strokeWidth="1.5"
                  viewBox="0 0 24 24"
                  fill="none"
                  xmlns="http://www.w3.org/2000/svg"
                  className="h-5 w-5"
                >
                  <path
                    d="M3 5H11"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                  <path
                    d="M3 12H16"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                  <path
                    d="M3 19H21"
                    stroke="currentColor"
                    strokeWidth="1.5"
                    strokeLinecap="round"
                    strokeLinejoin="round"
                  ></path>
                </svg>
                <span className="sr-only">Toggle Menu</span>
              </Button>
            </SheetTrigger>
            <SheetContent side="left">
              <div className="flex flex-col space-y-4">
                <Link to="/" className="mr-6 flex items-center space-x-2">
                  <Diamond className="h-6 w-6" />
                  <span className="font-bold">Pivot Point</span>
                </Link>
                <nav className="flex flex-col space-y-2 text-sm font-medium">
                  <Link to="/" className="text-foreground">
                    Home
                  </Link>
                  <Link to="/my-opportunities" className="text-foreground/60">
                    My Opportunities
                  </Link>
                  <Link
                    to="/prioritization-matrix"
                    className="text-foreground/60"
                  >
                    Matrix
                  </Link>
                </nav>
              </div>
            </SheetContent>
          </Sheet>
        </div>
        <div className="flex items-center">
          <nav className="flex items-center">
            {user ? (
              <Link to="/logout">
                <Button>Logout</Button>
              </Link>
            ) : (
              <>
                <Link to="/login">
                  <Button variant="ghost">Login</Button>
                </Link>
                <Link to="/signup">
                  <Button>Sign Up</Button>
                </Link>
              </>
            )}
          </nav>
        </div>
      </div>
    </header>
  );
}
